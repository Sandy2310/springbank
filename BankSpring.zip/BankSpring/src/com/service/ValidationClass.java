package com.service;

//import java.util.List;

import com.bean.Bean;
//import com.dao.AccountDao;

public class ValidationClass
{
Bean bean= new Bean();


public static boolean validateName(String name)
{
       String pattern="[A-Z][a-z]*([ ][A-Z][a-z]*)*";
       if(name.matches(pattern))
       return true;
       else
       return false;
}

public static boolean ValidateNumber(String number)
{
    String pattern="(91)||(91 )?[6-9][0-9]{9}";
   if(number.matches(pattern))
   {
       return true;
   }
   else
       return false;
}




}
