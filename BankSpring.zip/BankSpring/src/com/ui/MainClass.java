package com.ui;

public class MainClass 
{
public static void main(String[] args)
{
FrontEnd front= new FrontEnd();
front.display();
}
}