package com.dao;

import java.util.ArrayList;
import java.util.List;

import com.bean.Bean;
import com.bean.Transaction;


public class AccountDao 
{
public List<Bean> userlist= new ArrayList<>();
public List<Transaction> transactionList= new ArrayList();


	public void storeData(Bean bean)
{
	userlist.add(bean);
	//System.out.println(userlist);
}

	public List<Bean> returnData()
	{
		//System.out.println(userlist);
		return userlist;
	}
	
	public void storeTransaction(Transaction transaction)
	{
		transactionList.add(transaction);
		
	}
	
	public List<Transaction> returnTransaction()
	{
		//System.out.println(transactionList);
		return transactionList;
	}
}
