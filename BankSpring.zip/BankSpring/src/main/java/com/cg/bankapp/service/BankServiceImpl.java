package com.cg.bankapp.service;

import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;

import com.cg.bankapp.bean.Bank;
import com.cg.bankapp.dao.BankDao;
import com.cg.bankapp.exception.BankException;


@Service
public class BankServiceImpl implements BankService
{
@Autowired
BankDao bankDao;



public Bank getDetailsById(int accountId) throws BankException {
	try {
		return	bankDao.findById(accountId).get();
		}
		catch(Exception ex)
		{
			throw new BankException(ex.getMessage());
		}
}

@Override
public Bank addBankAccount(Bank bank) throws BankException {
try {
	 return	bankDao.save(bank); 
}
catch(Exception ex)
{
	throw new BankException(ex.getMessage());	
}
 
}

@Override
public double showBalance(int accountId) throws BankException {
	try
	{
		Bank bank=bankDao.findById(accountId).get();
		return bank.getBalance();
	}
	catch(Exception ex)
	{
		throw new BankException(ex.getMessage());
	}
}


public double depositAmount(int accountId, double amount) throws BankException {
    try {
        Optional<Bank> optional=bankDao.findById(accountId);
        Bank dp=optional.get();
        dp.setBalance(optional.get().getBalance()+amount);
        bankDao.save(dp);
        return bankDao.findById(accountId).get().getBalance();
    }catch(Exception e) {
        throw new BankException(e.getMessage());
    }
   
}


@Override
public double withdrawAmount(int accountId,double withdraw) throws BankException {
    try{
    	Optional<Bank> optional=bankDao.findById(accountId);
    	if(optional.isPresent())
    	{
        Bank wd=optional.get();
        wd.setBalance(optional.get().getBalance()-withdraw);
        bankDao.save(wd);
        return bankDao.findById(accountId).get().getBalance();
        }
        else
        {
            throw new BankException("Customer with accountnumber " + accountId + " does not exit");
        }
        
    }catch(Exception e) {
        throw new BankException(e.getMessage());
    }
}


@Override
public Bank cashTransfer(int source, int destination, double money) throws BankException 
{
    try{
        Optional<Bank> optional1=bankDao.findById(source);
        Optional<Bank> optional2=bankDao.findById(destination);
        if(optional1.isPresent() && optional2.isPresent()) {
            Bank deposit=optional1.get();
            Bank credit=optional2.get();
            deposit.setBalance(deposit.getBalance()-money);
            credit.setBalance(deposit.getBalance()+money);
            bankDao.save(deposit);
            bankDao.save(credit);
            return bankDao.findById(source).get();
        }
        else
        {
            throw new BankException("Customer with accountnumber " + source + " does not exit");
        }
    }catch(Exception e) {
        throw new BankException(e.getMessage());
    }
}
	


@Override
public void getDetailsbyLogin(String username, String password) throws BankException 
{

}

}



